# Инструкция

Установка нужных библиотек: `npm install`.

Проверка кода: `npm test -s` или `make test`.

Запуск приложения: `npm start` или `make start`.
