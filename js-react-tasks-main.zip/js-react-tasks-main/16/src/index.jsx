import ReactDOM from 'react-dom/client';
import React from 'react';

import Component from './Component.jsx';

const root = ReactDOM.createRoot(document.getElementById('container'));
root.render(<Component />);
