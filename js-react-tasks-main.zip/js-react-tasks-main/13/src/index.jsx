import ReactDOM from 'react-dom/client';
import React from 'react';

import TodoBox from './TodoBox.jsx';

const root = ReactDOM.createRoot(document.getElementById('container'));
root.render(<TodoBox />);
