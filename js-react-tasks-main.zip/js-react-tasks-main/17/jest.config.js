const config = {
  testEnvironment: "jsdom",
  testEnvironmentOptions: {
    customExportConditions: ["node"],
  },
};
module.exports = config;
